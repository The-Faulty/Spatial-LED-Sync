from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from config import EngineConfig, WallConfig
from spatial_config import SpatialConfig, SpatialDevice, SpatialStrip, parse_spatial_config, spatial_config_to_dict


@dataclass(frozen=True)
class DeviceRoute:
    device: SpatialDevice
    global_indices: np.ndarray
    device_indices: np.ndarray


class SpatialRoomTopology:
    def __init__(self, config: EngineConfig):
        self.config = config
        self.spatial: SpatialConfig = parse_spatial_config(config.spatial, config.total_leds)
        self.config.spatial = spatial_config_to_dict(self.spatial)
        self.total = sum(strip.led_count for strip in self.spatial.strips)
        self.global_indices = np.arange(self.total, dtype=np.int32)
        self.positions = np.zeros((self.total, 3), dtype=np.float32)
        self.wall_u = np.zeros(self.total, dtype=np.float32)
        self.wall_v = np.zeros(self.total, dtype=np.float32)
        self.strip_blend = np.zeros(self.total, dtype=np.float32)
        self.wall_names: list[str] = []
        self.strip_ids: list[str] = []
        self.sync_modes: list[str] = []
        self.effective_tv_roles: list[str] = []
        self.extension_modes: list[str] = []
        self.device_ids: list[str] = []
        self.device_led_indices = np.zeros(self.total, dtype=np.int32)
        self.strip_ranges: dict[str, tuple[int, int]] = {}
        self.wall_ranges: dict[str, list[int]] = {"front": [], "left": [], "rear": [], "right": []}
        self.devices = {device.id: device for device in self.spatial.devices}
        self.strips = {strip.id: strip for strip in self.spatial.strips}
        self._effective_role_by_strip = self._resolve_effective_tv_roles()
        self._routes: list[DeviceRoute] | None = None
        self._build()

    @property
    def enabled(self) -> bool:
        return self.spatial.enabled

    def apply_legacy_fields(self, config: EngineConfig) -> None:
        if self.total <= 0:
            return
        config.total_leds = self.total
        for wall in ("front", "left", "rear", "right"):
            indices = self.wall_ranges[wall]
            if indices:
                setattr(config, f"{wall}_wall", WallConfig(indices[0], indices[-1]))
            else:
                setattr(config, f"{wall}_wall", WallConfig(0, 0))

        tv_indices = self.tv_wall_indices()
        if tv_indices:
            config.tv_left_boundary = tv_indices[0]
            config.tv_center_led = tv_indices[len(tv_indices) // 2]
            config.tv_right_boundary = tv_indices[-1]

    def range_inclusive(self, start: int, end: int) -> list[int]:
        start %= self.total
        end %= self.total
        if start <= end:
            return list(range(start, end + 1))
        return list(range(start, self.total)) + list(range(0, end + 1))

    def circular_distance(self, a: int, b: int) -> int:
        diff = abs((a % self.total) - (b % self.total))
        return min(diff, self.total - diff)

    def signed_distance(self, origin: float, position: int, direction: int) -> float:
        position %= self.total
        origin %= self.total
        if direction >= 0:
            return (position - origin) % self.total
        return (origin - position) % self.total

    def wall_for_led(self, led: int) -> str | None:
        led %= self.total
        return self.wall_names[led] if 0 <= led < len(self.wall_names) else None

    def adjacent_walls(self, wall: str) -> tuple[str, str]:
        order = self.config.clockwise_order
        idx = order.index(wall)
        return order[(idx - 1) % len(order)], order[(idx + 1) % len(order)]

    def direction_from_to(self, origin: int, target_wall: str) -> int:
        indices = self.wall_ranges[target_wall]
        target = indices[len(indices) // 2] if indices else origin
        cw = (target - origin) % self.total
        ccw = (origin - target) % self.total
        return 1 if cw <= ccw else -1

    def origin_for_edge(self, edge: str, intensity: float):
        from topology import Origin

        led = self.nearest_led_to_point(self.event_origin_point(edge))
        radius = self.config.normal_spill_radius
        if intensity >= self.config.level2_threshold:
            radius = self.total // 2
        elif intensity >= self.config.level1_threshold:
            radius = self.config.strong_spill_radius
        return Origin(led, (-1, 1), radius, f"screen-{edge}")

    def event_origin_point(self, edge: str) -> np.ndarray:
        projected = self._tv_projection_edge_point(edge)
        if projected is not None:
            return projected
        tv = self.spatial.tv
        left_u = tv.center_u - tv.width / 2.0
        right_u = tv.center_u + tv.width / 2.0
        top_v = tv.center_v + tv.height / 2.0
        bottom_v = tv.center_v - tv.height / 2.0
        if edge == "left":
            return self.wall_point(tv.wall, left_u, tv.center_v)
        if edge == "right":
            return self.wall_point(tv.wall, right_u, tv.center_v)
        if edge == "bottom":
            return self.wall_point(tv.wall, tv.center_u, bottom_v)
        return self.wall_point(tv.wall, tv.center_u, top_v)

    def _tv_projection_edge_point(self, edge: str) -> np.ndarray | None:
        points: list[np.ndarray] = []
        for strip in self.spatial.strips:
            role = self.effective_tv_role_for_strip(strip.id)
            if role != edge or strip.sync_mode not in {"tv_image", "blend"} or not strip.tv_fill_spatial:
                continue
            start, end = self.strip_ranges.get(strip.id, (0, 0))
            idx = np.arange(start, end, dtype=np.int32)
            fill_idx = self._tv_fill_indices(idx, role, strip)
            if fill_idx.size:
                points.append(np.mean(self.positions[fill_idx], axis=0))
        if not points:
            return None
        return np.mean(np.stack(points, axis=0), axis=0).astype(np.float32)

    def nearest_led_to_point(self, point: np.ndarray) -> int:
        if self.total <= 0:
            return 0
        distances = np.linalg.norm(self.positions - point.reshape(1, 3), axis=1)
        return int(np.argmin(distances))

    def room_center(self) -> np.ndarray:
        room = self.spatial.room
        return np.array([room.width / 2.0, room.height / 2.0, room.depth / 2.0], dtype=np.float32)

    def room_diagonal(self) -> float:
        room = self.spatial.room
        return float(np.linalg.norm([room.width, room.height, room.depth]))

    def device_routes(self) -> list[DeviceRoute]:
        if self._routes is not None:
            return self._routes
        routes: list[DeviceRoute] = []
        for device in self.spatial.devices:
            if not device.enabled:
                continue
            indices = np.array([idx for idx, did in enumerate(self.device_ids) if did == device.id], dtype=np.int32)
            if indices.size == 0:
                continue
            routes.append(DeviceRoute(device, indices, self.device_led_indices[indices]))
        self._routes = routes
        return routes

    def tv_wall_indices(self) -> list[int]:
        tv = self.spatial.tv
        left = tv.center_u - tv.width / 2.0
        right = tv.center_u + tv.width / 2.0
        bottom = tv.center_v - tv.height / 2.0
        top = tv.center_v + tv.height / 2.0
        result = [
            idx
            for idx, wall in enumerate(self.wall_names)
            if wall == tv.wall and left <= self.wall_u[idx] <= right and bottom <= self.wall_v[idx] <= top
        ]
        return result or self.wall_ranges.get(tv.wall, [])

    def front_ambient_indices(self) -> np.ndarray:
        tv_indices = np.array(self.tv_wall_indices(), dtype=np.int32)
        if tv_indices.size == 0:
            return tv_indices
        coverage = float(np.clip(self.config.front_ambient_coverage, 0.0, 1.0))
        if coverage <= 0.0:
            return np.array([], dtype=np.int32)
        if coverage >= 0.999:
            wall_indices = self._front_ambient_source_wall_indices(tv_indices)
            return wall_indices
        wall_indices = self._front_ambient_source_wall_indices(tv_indices)
        center = self.wall_u[tv_indices[len(tv_indices) // 2]]
        tv_width = max(0.001, self.spatial.tv.width)
        ambient_width = tv_width + (self._wall_span(self.spatial.tv.wall) - tv_width) * coverage
        mask = np.abs(self.wall_u[wall_indices] - center) <= ambient_width / 2.0
        selected = wall_indices[mask]
        return selected if selected.size else tv_indices

    def ambient_extension_from_leds(
        self,
        source_leds: np.ndarray,
        strength_boost: float = 0.0,
        reach_boost: float = 0.0,
    ) -> np.ndarray:
        colors = np.zeros((self.total, 3), dtype=np.float32)
        if source_leds.size == 0 or self.total <= 0:
            return colors
        boost_intensity = float(np.clip(self.config.ambient_side_spill_boost_intensity, 0.0, 2.0))
        strength_boost = float(np.clip(strength_boost, 0.0, 1.0)) * boost_intensity
        reach_boost = float(np.clip(reach_boost, 0.0, 1.0)) * boost_intensity
        base_intensity = float(np.clip(self.config.ambient_side_spill_base_intensity, 0.0, 1.0))
        for strip in self.spatial.strips:
            parent_id = strip.extends_strip_id.strip()
            if strip.sync_mode != "spatial" or not parent_id or strip.extension_mode == "effects_only":
                continue
            start, end = self.strip_ranges.get(strip.id, (0, 0))
            parent_start, parent_end = self.strip_ranges.get(parent_id, (0, 0))
            idx = np.arange(start, end, dtype=np.int32)
            parent_idx = np.arange(parent_start, parent_end, dtype=np.int32)
            if idx.size == 0 or parent_idx.size == 0:
                continue
            edge_offset = self._nearest_parent_edge_offset(idx, parent_idx)
            edge_color = source_leds[parent_idx[edge_offset]].reshape(1, 3)
            fade = self._fade_from_parent_edge(idx, parent_idx[edge_offset], strip, reach_boost=reach_boost).reshape(-1, 1)
            strength = float(np.clip(strip.extension_strength * (1.0 + strength_boost * 0.85), 0.0, 1.0))
            output_cap = float(np.clip(base_intensity * (1.0 + strength_boost * 0.85), 0.0, 1.0))
            colors[idx] = np.clip(edge_color * fade * strength * base_intensity, 0.0, output_cap)
        return colors

    def tv_sample_colors(self, frame_bgr: np.ndarray | None) -> np.ndarray:
        colors = np.zeros((self.total, 3), dtype=np.float32)
        if frame_bgr is None or frame_bgr.size == 0 or self.total <= 0:
            return colors
        frame = frame_bgr[:, :, ::-1].astype(np.float32) / 255.0
        for strip in self.spatial.strips:
            role = self.effective_tv_role_for_strip(strip.id)
            if role == "none" or strip.sync_mode not in {"tv_image", "blend"}:
                continue
            start, end = self.strip_ranges.get(strip.id, (0, 0))
            idx = np.arange(start, end, dtype=np.int32)
            if idx.size:
                fill_idx = self._tv_fill_indices(idx, role, strip)
                if fill_idx.size == 0:
                    continue
                sampled = self._sample_tv_role(frame, fill_idx, role, strip)
                if strip.extends_strip_id.strip():
                    sampled = self._apply_extension_mode(sampled, fill_idx, role, strip)
                colors[fill_idx] = sampled

        roles = np.array(self.effective_tv_roles, dtype=object)
        tv_capable = np.array([mode in {"tv_image", "blend"} for mode in self.sync_modes], dtype=bool)
        unmapped = np.nonzero((roles == "none") & tv_capable & self._same_wall_tv_mask())[0].astype(np.int32)
        if unmapped.size:
            colors[unmapped] = self._sample_tv_rect(frame, unmapped)
        return colors

    def ambient_extension_colors(self, frame_bgr: np.ndarray | None) -> np.ndarray:
        colors = np.zeros((self.total, 3), dtype=np.float32)
        if frame_bgr is None or frame_bgr.size == 0 or self.total <= 0:
            return colors
        frame = frame_bgr[:, :, ::-1].astype(np.float32) / 255.0
        for strip in self.spatial.strips:
            parent_id = strip.extends_strip_id.strip()
            if strip.sync_mode != "spatial" or not parent_id or strip.extension_mode == "effects_only":
                continue
            parent = self.strips.get(parent_id)
            role = self.effective_tv_role_for_strip(parent_id)
            if parent is None or role == "none":
                continue
            start, end = self.strip_ranges.get(strip.id, (0, 0))
            parent_start, parent_end = self.strip_ranges.get(parent_id, (0, 0))
            idx = np.arange(start, end, dtype=np.int32)
            parent_idx = np.arange(parent_start, parent_end, dtype=np.int32)
            if idx.size == 0 or parent_idx.size == 0:
                continue
            parent_samples = self._sample_tv_role(frame, parent_idx, role)
            edge_offset = self._nearest_parent_edge_offset(idx, parent_idx)
            edge_color = parent_samples[edge_offset].reshape(1, 3)
            fade = self._fade_from_parent_edge(idx, parent_idx[edge_offset], strip).reshape(-1, 1)
            strength = float(np.clip(strip.extension_strength, 0.0, 1.0))
            colors[idx] = np.clip(edge_color * fade * strength * 0.45, 0.0, 0.25)
        return colors

    def effective_tv_role_for_strip(self, strip_id: str) -> str:
        return self._effective_role_by_strip.get(strip_id, "none")

    def wall_point(self, wall: str, u: float, v: float) -> np.ndarray:
        room = self.spatial.room
        u = float(u)
        v = float(v)
        if wall == "front":
            return np.array([u, v, 0.0], dtype=np.float32)
        if wall == "rear":
            return np.array([room.width - u, v, room.depth], dtype=np.float32)
        if wall == "left":
            return np.array([room.width, v, u], dtype=np.float32)
        return np.array([0.0, v, room.depth - u], dtype=np.float32)

    def _build(self) -> None:
        cursor = 0
        for strip in self.spatial.strips:
            start = cursor
            self._build_strip(strip, cursor)
            cursor += strip.led_count
            self.strip_ranges[strip.id] = (start, cursor)

    def _build_strip(self, strip: SpatialStrip, cursor: int) -> None:
        count = strip.led_count
        t = np.linspace(0.0, 1.0, count, dtype=np.float32)
        if strip.direction == "reverse":
            t = 1.0 - t
        us = strip.start_u + (strip.end_u - strip.start_u) * t
        vs = strip.start_v + (strip.end_v - strip.start_v) * t
        for offset in range(count):
            idx = cursor + offset
            self.positions[idx] = self.wall_point(strip.wall, float(us[offset]), float(vs[offset]))
            self.wall_u[idx] = us[offset]
            self.wall_v[idx] = vs[offset]
            self.strip_blend[idx] = strip.blend
            self.wall_names.append(strip.wall)
            self.strip_ids.append(strip.id)
            self.sync_modes.append(strip.sync_mode)
            self.effective_tv_roles.append(self.effective_tv_role_for_strip(strip.id))
            self.extension_modes.append(strip.extension_mode)
            self.device_ids.append(strip.device_id)
            self.device_led_indices[idx] = strip.device_start + offset
            self.wall_ranges[strip.wall].append(idx)

    def _resolve_effective_tv_roles(self) -> dict[str, str]:
        by_id = {strip.id: strip for strip in self.spatial.strips}
        resolved: dict[str, str] = {}

        def resolve(strip: SpatialStrip, seen: set[str]) -> str:
            if strip.id in resolved:
                return resolved[strip.id]
            if strip.id in seen:
                return "none"
            if strip.tv_role != "none":
                resolved[strip.id] = strip.tv_role
                return strip.tv_role
            parent_id = strip.extends_strip_id.strip()
            parent = by_id.get(parent_id)
            if parent is None:
                resolved[strip.id] = "none"
                return "none"
            role = resolve(parent, seen | {strip.id})
            resolved[strip.id] = role
            return role

        for strip in self.spatial.strips:
            resolve(strip, set())
        return resolved

    def _same_wall_tv_mask(self) -> np.ndarray:
        tv = self.spatial.tv
        left = tv.center_u - tv.width / 2.0
        right = tv.center_u + tv.width / 2.0
        bottom = tv.center_v - tv.height / 2.0
        top = tv.center_v + tv.height / 2.0
        return np.array(
            [
                wall == tv.wall and left <= self.wall_u[idx] <= right and bottom <= self.wall_v[idx] <= top
                for idx, wall in enumerate(self.wall_names)
            ],
            dtype=bool,
        )

    def _wall_span(self, wall: str) -> float:
        room = self.spatial.room
        return room.width if wall in {"front", "rear"} else room.depth

    def _front_ambient_source_wall_indices(self, fallback: np.ndarray) -> np.ndarray:
        indices = [
            idx
            for idx in self.wall_ranges.get(self.spatial.tv.wall, fallback.tolist())
            if not self.strips.get(self.strip_ids[idx]).extends_strip_id.strip()
        ]
        return np.array(indices, dtype=np.int32) if indices else fallback

    def _sample_tv_rect(self, frame: np.ndarray, idx: np.ndarray) -> np.ndarray:
        height, width = frame.shape[:2]
        tv = self.spatial.tv
        left = tv.center_u - tv.width / 2.0
        bottom = tv.center_v - tv.height / 2.0
        tv_w = max(0.001, tv.width)
        tv_h = max(0.001, tv.height)
        u_norm = np.clip((self.wall_u[idx] - left) / tv_w, 0.0, 1.0)
        v_norm = np.clip((self.wall_v[idx] - bottom) / tv_h, 0.0, 1.0)
        xs = np.clip((u_norm * (width - 1)).astype(np.int32), 0, width - 1)
        ys = np.clip(((1.0 - v_norm) * (height - 1)).astype(np.int32), 0, height - 1)
        return frame[ys, xs]

    def _sample_tv_role(self, frame: np.ndarray, idx: np.ndarray, role: str, strip: SpatialStrip | None = None) -> np.ndarray:
        height, width = frame.shape[:2]
        sample_role = self._mirrored_sample_role(role)
        if role in {"top", "bottom"}:
            progress = self._tv_edge_progress(idx, role, strip)
            if self.spatial.tv.mirror_horizontal:
                progress = 1.0 - progress
            xs = np.clip(np.rint(progress * (width - 1)).astype(np.int32), 0, width - 1)
            edge_h = max(1, int(round(height * 0.04)))
            band = frame[:edge_h, :] if role == "top" else frame[height - edge_h :, :]
            sampled = band[:, xs].mean(axis=0)
        else:
            progress = self._tv_edge_progress(idx, role, strip)
            ys = np.clip(np.rint((1.0 - progress) * (height - 1)).astype(np.int32), 0, height - 1)
            edge_w = max(1, int(round(width * 0.04)))
            band = frame[:, :edge_w] if sample_role == "left" else frame[:, width - edge_w :]
            sampled = band[ys, :].mean(axis=1)
        return sampled

    def _mirrored_sample_role(self, role: str) -> str:
        if not self.spatial.tv.mirror_horizontal:
            return role
        if role == "left":
            return "right"
        if role == "right":
            return "left"
        return role

    def _apply_extension_mode(self, colors: np.ndarray, idx: np.ndarray, role: str, strip: SpatialStrip) -> np.ndarray:
        strength = float(np.clip(strip.extension_strength, 0.0, 1.0))
        softness = float(np.clip(strip.extension_softness, 0.0, 1.0))
        if strip.sync_mode == "spatial":
            return np.zeros_like(colors)
        if strip.extension_mode == "effects_only":
            return colors
        if strip.extension_mode == "edge_reach":
            distances = self._extension_distance_from_tv_edge(idx, role).reshape(-1, 1)
            intensity = np.max(colors, axis=1, keepdims=True)
            gate = np.power(np.clip(intensity, 0.0, 1.0), distances * (2.5 + softness * 2.0))
            return np.clip(colors * gate * strength, 0.0, 1.0)

        softened = self._smooth_strip_colors(colors, softness)
        luminance = (
            softened[:, 0:1] * 0.2126
            + softened[:, 1:2] * 0.7152
            + softened[:, 2:3] * 0.0722
        )
        desaturate = softness * 0.35
        softened = softened * (1.0 - desaturate) + luminance * desaturate
        return np.clip(softened * strength, 0.0, 1.0)

    def _tv_fill_indices(self, idx: np.ndarray, role: str, strip: SpatialStrip) -> np.ndarray:
        fill = float(np.clip(strip.tv_fill, 0.0, 1.0))
        if idx.size == 0:
            return idx
        if role in {"top", "bottom"}:
            axis = self.wall_u[idx]
            tv_span = self.spatial.tv.width
        else:
            axis = self.wall_v[idx]
            tv_span = self.spatial.tv.height
        strip_min = float(np.min(axis))
        strip_max = float(np.max(axis))
        strip_span = max(0.001, strip_max - strip_min)
        center = self._tv_fill_center(axis, role, strip)
        width = min(strip_span, tv_span + max(0.0, strip_span - tv_span) * fill)
        mask = np.abs(axis - center) <= width / 2.0 + 1e-5
        if not np.any(mask):
            target_count = max(1, int(round(idx.size * min(1.0, width / strip_span))))
            order_center = idx.size // 2
            half = target_count // 2
            fallback = np.zeros(idx.size, dtype=bool)
            fallback[max(0, order_center - half) : min(idx.size, order_center + half + 1)] = True
            mask = fallback
        return idx[mask]

    def _tv_fill_center(self, axis: np.ndarray, role: str, strip: SpatialStrip) -> float:
        if strip.tv_fill_spatial:
            tv = self.spatial.tv
            return float(tv.center_u if role in {"top", "bottom"} else tv.center_v)
        return float((np.min(axis) + np.max(axis)) / 2.0)

    def _smooth_strip_colors(self, colors: np.ndarray, softness: float) -> np.ndarray:
        if colors.shape[0] <= 1 or softness <= 0.0:
            return colors
        smoothed = colors.copy()
        passes = max(1, int(round(softness * 5.0)))
        for _ in range(passes):
            padded = np.pad(smoothed, ((1, 1), (0, 0)), mode="edge")
            smoothed = padded[:-2] * 0.25 + padded[1:-1] * 0.5 + padded[2:] * 0.25
        return smoothed

    def _nearest_parent_edge_offset(self, idx: np.ndarray, parent_idx: np.ndarray) -> int:
        extension_endpoints = self.positions[[idx[0], idx[-1]]]
        parent_endpoints = self.positions[[parent_idx[0], parent_idx[-1]]]
        distances = np.linalg.norm(parent_endpoints[:, None, :] - extension_endpoints[None, :, :], axis=2)
        return 0 if int(np.argmin(distances)) // 2 == 0 else parent_idx.size - 1

    def _fade_from_parent_edge(
        self,
        idx: np.ndarray,
        parent_edge_idx: int,
        strip: SpatialStrip,
        reach_boost: float = 0.0,
    ) -> np.ndarray:
        distances = np.linalg.norm(self.positions[idx] - self.positions[parent_edge_idx].reshape(1, 3), axis=1)
        if distances.size == 0:
            return distances
        min_distance = float(np.min(distances))
        span = max(0.001, float(np.max(distances) - min_distance))
        normalized = np.clip((distances - min_distance) / span, 0.0, 1.0)
        softness = float(np.clip(strip.extension_softness, 0.0, 1.0))
        falloff = 5.5 + softness * 4.5
        if strip.extension_mode == "edge_reach":
            falloff += 2.0
        falloff /= 1.0 + float(np.clip(reach_boost, 0.0, 2.0)) * 2.4
        return np.exp(-normalized * falloff).astype(np.float32)

    def _extension_distance_from_tv_edge(self, idx: np.ndarray, role: str) -> np.ndarray:
        tv = self.spatial.tv
        progress = self._tv_edge_progress(idx, role)
        if role in {"top", "bottom"}:
            edge_u = tv.center_u - tv.width / 2.0 + progress * tv.width
            edge_v = np.full_like(edge_u, tv.center_v + tv.height / 2.0 if role == "top" else tv.center_v - tv.height / 2.0)
        else:
            edge_u = np.full_like(progress, tv.center_u - tv.width / 2.0 if role == "left" else tv.center_u + tv.width / 2.0)
            edge_v = tv.center_v - tv.height / 2.0 + progress * tv.height
        edge_points = np.array([self.wall_point(tv.wall, float(u), float(v)) for u, v in zip(edge_u, edge_v)], dtype=np.float32)
        distances = np.linalg.norm(self.positions[idx] - edge_points, axis=1)
        if distances.size == 0:
            return distances
        min_distance = float(np.min(distances))
        span = max(0.001, float(np.max(distances) - min_distance))
        return np.clip((distances - min_distance) / span, 0.0, 1.0).astype(np.float32)

    def _tv_edge_progress(self, idx: np.ndarray, role: str, strip: SpatialStrip | None = None) -> np.ndarray:
        tv = self.spatial.tv
        if role in {"top", "bottom"}:
            axis = self.wall_u[idx]
        else:
            axis = self.wall_v[idx]
        axis_min = float(np.min(axis))
        axis_max = float(np.max(axis))
        axis_span = axis_max - axis_min
        if axis_span > 0.0001:
            return np.clip((axis - axis_min) / axis_span, 0.0, 1.0).astype(np.float32)
        return np.linspace(0.0, 1.0, idx.size, dtype=np.float32)
